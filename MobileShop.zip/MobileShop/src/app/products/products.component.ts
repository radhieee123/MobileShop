import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { removeDebugNodeFromIndex } from '@angular/core/src/debug/debug_node';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  @Input() data;
  @Input() removed;
  removeProd:any;
  products:any;
  inCart:Array<any>=[];
  constructor() { }

  ngOnInit() {
    this.products=this.data;
  }
  loadProducts(){
    this.products=this.data;
  }

  addProduct(phone:any) {
    this.inCart.push(phone);
    this.products.splice(this.products.indexOf(phone),1)
    console.log(this.removed);
  }
}
