export const ProductList=[
    {
        "isPublished":true,
        "name":"Redmi Note 5",
        "path": "./assets/phones/xiaomi.png",
        "price":12000
    },
    {
        "isPublished":true,
        "name":"Iphone",
        "path": "./assets/phones/iphone.png",
        "price":32000
    },
    {
        "isPublished":true,
        "name":"Redmi Note 5",
        "path": "./assets/phones/xiaomi.png",
        "price":12000
    },
    {
        "isPublished":true,
        "name":"Iphone",
        "path": "./assets/phones/iphone.png",
        "price":32000
    },
    {
        "isPublished":true,
        "name":"Redmi Note 5",
        "path": "./assets/phones/xiaomi.png",
        "price":12000
    },
    {
        "isPublished":true,
        "name":"Iphone",
        "path": "./assets/phones/iphone.png",
        "price":32000
    },
    {
        "isPublished":true,
        "name":"Redmi Note 5",
        "path": "./assets/phones/xiaomi.png",
        "price":12000
    },
    {
        "isPublished":true,
        "name":"Iphone",
        "path": "./assets/phones/iphone.png",
        "price":32000
    },
    {
        "isPublished":true,
        "name":"Samsung",
        "path": "./assets/phones/samsung.png",
        "price":10000
    }
];
