import { Component, OnInit, Input } from '@angular/core';
import { ProductList } from '../product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  //cart:any=ProductList;
  @Input() cart;
  cartProduct:any;
  removedProducts:Array<any>=[];
  constructor() { }

  ngOnInit() {
    this.cartProduct=this.cart;
  }

  removeProduct(phone:any) {
    this.removedProducts.push(phone);
    this.cartProduct.splice(this.cartProduct.indexOf(phone),1)
  }
}
