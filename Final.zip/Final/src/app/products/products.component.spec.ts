import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsComponent } from './products.component';
import { AddRemoveService } from '../add-remove.service';

class MockAddRemoveService { 
  cartList = false;

  getAllProducts() {
    return this.cartList;
  }
  addToCart(product:any) {
    return this.cartList;
  }
}
describe('ProductsComponent', () => {
  let component: ProductsComponent;
  let fixture: ComponentFixture<ProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsComponent ],
      providers:[
        { provide: AddRemoveService,useClass:MockAddRemoveService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add product',()=>{
    let product:any;
    expect(component.addProduct(product)).toBeUndefined();
  })
});
