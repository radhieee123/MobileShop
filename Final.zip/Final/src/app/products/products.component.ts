import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AddRemoveService } from '../add-remove.service';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  @Input() data;
  @Input() removed;
  removeProd:any;
  products:any;
  inCart:Array<any>=[];
  constructor(private addRemove:AddRemoveService) { }

  ngOnInit() {
    this.products=this.addRemove.getAllProducts();
  }

  addProduct(phone:any) {
    console.log(phone);
    this.addRemove.addToCart(phone);
  }
}
