import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ShoppingComponent } from './shopping/shopping.component';
import { CartComponent } from './cart/cart.component';
import { ProductsComponent } from './products/products.component';
import { AddRemoveService } from './add-remove.service';

@NgModule({
  declarations: [
    AppComponent,
    ShoppingComponent,
    CartComponent,
    ProductsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [AddRemoveService],
  bootstrap: [AppComponent]
})
export class AppModule { }
