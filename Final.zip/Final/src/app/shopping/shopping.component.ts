import { Component, OnInit, ViewChild } from '@angular/core';
import { ProductList } from '../product';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.scss']
})
export class ShoppingComponent implements OnInit {

  products:any=ProductList;

  constructor() { }

  ngOnInit() {
  }

}
