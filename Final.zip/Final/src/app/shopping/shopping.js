$(window).resize(function() {
    if ($(window).width() <= 500) {
      $('.products').remove().insertAfter($('.cart'));
    } else {
      $('.products').remove().insertBefore($('.cart'));
    }
  })