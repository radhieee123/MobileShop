import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ShoppingComponent } from './shopping.component';
import { CartComponent } from '../cart/cart.component';
import { ProductsComponent } from '../products/products.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ShoppingComponent,
    CartComponent,
    ProductsComponent
  ]
})
export class ShoppingModule { }
