import { Injectable } from '@angular/core';
import { ProductList } from './product';

@Injectable()
export class AddRemoveService {

  products:Array<any>=ProductList;
  productList:Array<any>=[];
  cartList:Array<any>=[];

  constructor() { }

  getAllProducts() {
    this.products.forEach(element => {
      if(element.isPublished){
          this.productList.push(element);
      }
    });
    
    return this.productList;
  }

  addToCart(product:any){
    this.cartList.push(product);
    this.productList.splice(this.productList.indexOf(product),1);
  }

  removeFromCart(product:any) {
    this.productList.push(product);
    this.cartList.splice(this.cartList.indexOf(product),1);
  }
}
