import { TestBed, inject } from '@angular/core/testing';

import { AddRemoveService } from './add-remove.service';

describe('AddRemoveService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddRemoveService]
    });
  });

  it('should be created', inject([AddRemoveService], (service: AddRemoveService) => {
    expect(service).toBeTruthy();
  }));
  it('should add product to cart',inject([AddRemoveService],(service:AddRemoveService)=>{
    let product:any;
    expect(service.addToCart(product)).toBeUndefined();
  }))
  it('should remove product from cart',inject([AddRemoveService],(service:AddRemoveService)=>{
    let product:any;
    expect(service.removeFromCart(product)).toBeUndefined();
  }))
  it('should remove product from cart',inject([AddRemoveService],(service:AddRemoveService)=>{
    expect(service.getAllProducts()).toBeTruthy();
  }))
});
