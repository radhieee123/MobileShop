import { Component, OnInit, Input } from '@angular/core';
import { AddRemoveService } from '../add-remove.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  //cart:any=ProductList;
  @Input() cart;
  cartProduct:any;
  removedProducts:Array<any>=[];
  constructor(private addRemove:AddRemoveService) { }

  ngOnInit() {
    this.cartProduct=this.addRemove.cartList;
  }

  removeProduct(phone:any) {
    this.addRemove.removeFromCart(phone);
  }
}
